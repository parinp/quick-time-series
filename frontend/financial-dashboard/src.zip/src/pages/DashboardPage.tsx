import React, { useState, useEffect } from 'react';
import { Container, Grid, Paper, Typography, CircularProgress, Box } from '@mui/material';
import ForecastChart from '../components/Charts/ForecastChart';
import { fetchDataSeries, runModelInference } from '../services/api';

const DashboardPage = () => {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState({
    historical: [],
    forecast: []
  });

  useEffect(() => {
    const loadData = async () => {
      try {
        // Fetch historical data
        const historicalData = await fetchDataSeries({
          start_date: '2023-01-01',
          end_date: '2023-12-31'
        });
        
        // Run a model for forecasting
        const forecastResult = await runModelInference('default_forecast', {
          horizon: 30
        });
        
        setData({
          historical: historicalData,
          forecast: forecastResult.forecast
        });
      } catch (error) {
        console.error('Error loading dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };
    
    loadData();
  }, []);

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Typography variant="h4" gutterBottom>
        Financial Analytics Dashboard
      </Typography>
      
      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', my: 4 }}>
          <CircularProgress />
        </Box>
      ) : (
        <Grid container spacing={3}>
          <Grid item xs={12}>
            <Paper sx={{ p: 2 }}>
              <ForecastChart 
                historicalData={data.historical} 
                forecastData={data.forecast} 
              />
            </Paper>
          </Grid>
        </Grid>
      )}
    </Container>
  );
};

export default DashboardPage;