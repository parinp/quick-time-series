// src/components/MLModels/FeatureImportancePanel.jsx
import React from 'react';
import { Box, Paper, Typography, List, ListItem, ListItemIcon, ListItemText, Chip } from '@mui/material';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Timeline } from '@mui/icons-material';

const FeatureImportancePanel = ({ features, prediction }) => {
  if (!features || features.length === 0 || !prediction) {
    return null;
  }
  
  // Create data for feature visualization
  const featuresUsed = prediction.features_used;
  
  // Get the latest feature values
  const latestFeatures = features[features.length - 1];
  
  // Create data for chart
  const featureChartData = featuresUsed.map(featureName => {
    let value = latestFeatures[featureName];
    
    // Normalize values for better visualization
    if (featureName === 'volume') {
      value = value / 1000000; // Convert to millions
    }
    
    return {
      name: featureName,
      value: value
    };
  }).filter(item => item.value !== undefined);
  
  return (
    <Paper sx={{ p: 3, mb: 3 }}>
      <Typography variant="h5" gutterBottom>Model Features Used</Typography>
      
      <ResponsiveContainer width="100%" height={300}>
        <BarChart 
          data={featureChartData}
          layout="vertical"
          margin={{ top: 5, right: 30, left: 150, bottom: 5 }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis type="number" />
          <YAxis 
            type="category" 
            dataKey="name" 
            tick={{ fontSize: 14 }}
          />
          <Tooltip 
            formatter={(value, name, props) => {
              if (props.payload.name === 'volume') {
                return [`${value.toFixed(2)}M`, 'Value'];
              }
              return [`${value.toFixed(4)}`, 'Value'];
            }}
          />
          <Bar dataKey="value" fill="#8884d8" name="Feature Value" />
        </BarChart>
      </ResponsiveContainer>
      
      <Box sx={{ mt: 3 }}>
        <Typography variant="subtitle1">Latest Feature Values:</Typography>
        <List dense>
          {featuresUsed.map(feature => {
            let featureValue = latestFeatures[feature];
            let displayValue = featureValue;
            
            // Format values for better readability
            if (feature === 'volume') {
              displayValue = `${(featureValue / 1000000).toFixed(2)}M`;
            } else if (typeof featureValue === 'number') {
              displayValue = featureValue.toFixed(4);
            }
            
            return (
              <ListItem key={feature}>
                <ListItemIcon>
                  <Timeline />
                </ListItemIcon>
                <ListItemText 
                  primary={`${feature}: ${displayValue}`} 
                  secondary={getFeatureDescription(feature)}
                />
              </ListItem>
            );
          })}
        </List>
      </Box>
    </Paper>
  );
};

// Helper function to provide descriptions for features
const getFeatureDescription = (feature) => {
  const descriptions = {
    price_open: "Opening price of the trading day",
    price_close: "Closing price of the trading day",
    price_change_pct: "Percentage change in price from previous day",
    volume: "Trading volume (number of shares traded)",
    trend_interest: "Search interest in the stock (if available)",
    volatility_5d: "5-day volatility measure",
    momentum_5d: "5-day price momentum"
  };
  
  return descriptions[feature] || "Feature used in prediction model";
};

export default FeatureImportancePanel;